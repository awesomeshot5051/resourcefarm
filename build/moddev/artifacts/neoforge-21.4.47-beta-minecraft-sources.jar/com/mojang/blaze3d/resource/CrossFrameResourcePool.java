package com.mojang.blaze3d.resource;

import com.google.common.annotations.VisibleForTesting;
import java.util.ArrayDeque;
import java.util.Collection;
import java.util.Deque;
import java.util.Iterator;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class CrossFrameResourcePool implements GraphicsResourceAllocator, AutoCloseable {
    private final int framesToKeepResource;
    private final Deque<CrossFrameResourcePool.ResourceEntry<?>> pool = new ArrayDeque<>();

    public CrossFrameResourcePool(int framesToKeepResource) {
        this.framesToKeepResource = framesToKeepResource;
    }

    public void endFrame() {
        Iterator<? extends CrossFrameResourcePool.ResourceEntry<?>> iterator = this.pool.iterator();

        while (iterator.hasNext()) {
            CrossFrameResourcePool.ResourceEntry<?> resourceentry = (CrossFrameResourcePool.ResourceEntry<?>)iterator.next();
            if (resourceentry.framesToLive-- == 0) {
                resourceentry.close();
                iterator.remove();
            }
        }
    }

    @Override
    public <T> T acquire(ResourceDescriptor<T> p_365509_) {
        Iterator<? extends CrossFrameResourcePool.ResourceEntry<?>> iterator = this.pool.iterator();

        while (iterator.hasNext()) {
            CrossFrameResourcePool.ResourceEntry<?> resourceentry = (CrossFrameResourcePool.ResourceEntry<?>)iterator.next();
            if (resourceentry.descriptor.equals(p_365509_)) {
                iterator.remove();
                return (T)resourceentry.value;
            }
        }

        return p_365509_.allocate();
    }

    @Override
    public <T> void release(ResourceDescriptor<T> p_360929_, T p_364526_) {
        this.pool.addFirst(new CrossFrameResourcePool.ResourceEntry<>(p_360929_, p_364526_, this.framesToKeepResource));
    }

    public void clear() {
        this.pool.forEach(CrossFrameResourcePool.ResourceEntry::close);
        this.pool.clear();
    }

    @Override
    public void close() {
        this.clear();
    }

    @VisibleForTesting
    protected Collection<CrossFrameResourcePool.ResourceEntry<?>> entries() {
        return this.pool;
    }

    @OnlyIn(Dist.CLIENT)
    @VisibleForTesting
    protected static final class ResourceEntry<T> implements AutoCloseable {
        final ResourceDescriptor<T> descriptor;
        final T value;
        int framesToLive;

        ResourceEntry(ResourceDescriptor<T> descriptor, T value, int framesToLive) {
            this.descriptor = descriptor;
            this.value = value;
            this.framesToLive = framesToLive;
        }

        @Override
        public void close() {
            this.descriptor.free(this.value);
        }
    }
}
