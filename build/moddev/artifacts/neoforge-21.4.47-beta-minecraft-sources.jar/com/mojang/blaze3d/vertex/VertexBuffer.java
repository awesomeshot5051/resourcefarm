package com.mojang.blaze3d.vertex;

import com.mojang.blaze3d.buffers.BufferType;
import com.mojang.blaze3d.buffers.BufferUsage;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.nio.ByteBuffer;
import java.util.function.Consumer;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.CompiledShaderProgram;
import net.minecraft.client.renderer.RenderType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.joml.Matrix4f;

@OnlyIn(Dist.CLIENT)
public class VertexBuffer implements AutoCloseable {
    private final BufferUsage usage;
    private final GpuBuffer vertexBuffer;
    @Nullable
    private GpuBuffer indexBuffer = null;
    private int arrayObjectId;
    @Nullable
    private VertexFormat format;
    @Nullable
    private RenderSystem.AutoStorageIndexBuffer sequentialIndices;
    private VertexFormat.IndexType indexType;
    private int indexCount;
    private VertexFormat.Mode mode;

    public VertexBuffer(BufferUsage usage) {
        this.usage = usage;
        RenderSystem.assertOnRenderThread();
        this.vertexBuffer = new GpuBuffer(BufferType.VERTICES, usage, 0);
        this.arrayObjectId = GlStateManager._glGenVertexArrays();
    }

    public static VertexBuffer uploadStatic(VertexFormat.Mode mode, VertexFormat format, Consumer<VertexConsumer> builder) {
        BufferBuilder bufferbuilder = Tesselator.getInstance().begin(mode, format);
        builder.accept(bufferbuilder);
        VertexBuffer vertexbuffer = new VertexBuffer(BufferUsage.STATIC_WRITE);
        vertexbuffer.bind();
        vertexbuffer.upload(bufferbuilder.buildOrThrow());
        unbind();
        return vertexbuffer;
    }

    public void upload(MeshData meshData) {
        MeshData meshdata = meshData;

        label40: {
            try {
                if (this.isInvalid()) {
                    break label40;
                }

                RenderSystem.assertOnRenderThread();
                MeshData.DrawState meshdata$drawstate = meshData.drawState();
                this.format = this.uploadVertexBuffer(meshdata$drawstate, meshData.vertexBuffer());
                this.sequentialIndices = this.uploadIndexBuffer(meshdata$drawstate, meshData.indexBuffer());
                this.indexCount = meshdata$drawstate.indexCount();
                this.indexType = meshdata$drawstate.indexType();
                this.mode = meshdata$drawstate.mode();
            } catch (Throwable throwable1) {
                if (meshData != null) {
                    try {
                        meshdata.close();
                    } catch (Throwable throwable) {
                        throwable1.addSuppressed(throwable);
                    }
                }

                throw throwable1;
            }

            if (meshData != null) {
                meshData.close();
            }

            return;
        }

        if (meshData != null) {
            meshData.close();
        }
    }

    public void uploadIndexBuffer(ByteBufferBuilder.Result result) {
        ByteBufferBuilder.Result bytebufferbuilder$result = result;

        label46: {
            try {
                if (this.isInvalid()) {
                    break label46;
                }

                RenderSystem.assertOnRenderThread();
                if (this.indexBuffer != null) {
                    this.indexBuffer.close();
                }

                this.indexBuffer = new GpuBuffer(BufferType.INDICES, this.usage, result.byteBuffer());
                this.sequentialIndices = null;
            } catch (Throwable throwable1) {
                if (result != null) {
                    try {
                        bytebufferbuilder$result.close();
                    } catch (Throwable throwable) {
                        throwable1.addSuppressed(throwable);
                    }
                }

                throw throwable1;
            }

            if (result != null) {
                result.close();
            }

            return;
        }

        if (result != null) {
            result.close();
        }
    }

    private VertexFormat uploadVertexBuffer(MeshData.DrawState drawState, @Nullable ByteBuffer buffer) {
        boolean flag = false;
        if (!drawState.format().equals(this.format)) {
            if (this.format != null) {
                this.format.clearBufferState();
            }

            this.vertexBuffer.bind();
            drawState.format().setupBufferState();
            flag = true;
        }

        if (buffer != null) {
            if (!flag) {
                this.vertexBuffer.bind();
            }

            this.vertexBuffer.resize(buffer.remaining());
            this.vertexBuffer.write(buffer, 0);
        }

        return drawState.format();
    }

    @Nullable
    private RenderSystem.AutoStorageIndexBuffer uploadIndexBuffer(MeshData.DrawState drawState, @Nullable ByteBuffer buffer) {
        if (buffer != null) {
            if (this.indexBuffer != null) {
                this.indexBuffer.close();
            }

            this.indexBuffer = new GpuBuffer(BufferType.INDICES, this.usage, buffer);
            return null;
        } else {
            RenderSystem.AutoStorageIndexBuffer rendersystem$autostorageindexbuffer = RenderSystem.getSequentialBuffer(drawState.mode());
            if (rendersystem$autostorageindexbuffer != this.sequentialIndices || !rendersystem$autostorageindexbuffer.hasStorage(drawState.indexCount())) {
                rendersystem$autostorageindexbuffer.bind(drawState.indexCount());
            }

            return rendersystem$autostorageindexbuffer;
        }
    }

    public void bind() {
        BufferUploader.invalidate();
        GlStateManager._glBindVertexArray(this.arrayObjectId);
    }

    public static void unbind() {
        BufferUploader.invalidate();
        GlStateManager._glBindVertexArray(0);
    }

    public void draw() {
        RenderSystem.drawElements(this.mode.asGLMode, this.indexCount, this.getIndexType().asGLType);
    }

    private VertexFormat.IndexType getIndexType() {
        RenderSystem.AutoStorageIndexBuffer rendersystem$autostorageindexbuffer = this.sequentialIndices;
        return rendersystem$autostorageindexbuffer != null ? rendersystem$autostorageindexbuffer.type() : this.indexType;
    }

    public void drawWithShader(Matrix4f frustumMatrix, Matrix4f projectionMatrix, @Nullable CompiledShaderProgram shader) {
        if (shader != null) {
            RenderSystem.assertOnRenderThread();
            shader.setDefaultUniforms(this.mode, frustumMatrix, projectionMatrix, Minecraft.getInstance().getWindow());
            shader.apply();
            this.draw();
            shader.clear();
        }
    }

    public void drawWithRenderType(RenderType renderType) {
        renderType.setupRenderState();
        this.bind();
        this.drawWithShader(RenderSystem.getModelViewMatrix(), RenderSystem.getProjectionMatrix(), RenderSystem.getShader());
        unbind();
        renderType.clearRenderState();
    }

    @Override
    public void close() {
        this.vertexBuffer.close();
        if (this.indexBuffer != null) {
            this.indexBuffer.close();
            this.indexBuffer = null;
        }

        if (this.arrayObjectId >= 0) {
            RenderSystem.glDeleteVertexArrays(this.arrayObjectId);
            this.arrayObjectId = -1;
        }
    }

    public VertexFormat getFormat() {
        return this.format;
    }

    public boolean isInvalid() {
        return this.arrayObjectId == -1;
    }
}
