package net.minecraft.client.data.models.blockstates;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.world.level.block.state.properties.Property;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public abstract class PropertyDispatch {
    private final Map<Selector, List<Variant>> values = Maps.newHashMap();

    protected void putValue(Selector selector, List<Variant> variants) {
        List<Variant> list = this.values.put(selector, variants);
        if (list != null) {
            throw new IllegalStateException("Value " + selector + " is already defined");
        }
    }

    Map<Selector, List<Variant>> getEntries() {
        this.verifyComplete();
        return ImmutableMap.copyOf(this.values);
    }

    private void verifyComplete() {
        List<Property<?>> list = this.getDefinedProperties();
        Stream<Selector> stream = Stream.of(Selector.empty());

        for (Property<?> property : list) {
            stream = stream.flatMap(p_387875_ -> property.getAllValues().map(p_387875_::extend));
        }

        List<Selector> list1 = stream.filter(p_386514_ -> !this.values.containsKey(p_386514_)).collect(Collectors.toList());
        if (!list1.isEmpty()) {
            throw new IllegalStateException("Missing definition for properties: " + list1);
        }
    }

    abstract List<Property<?>> getDefinedProperties();

    public static <T1 extends Comparable<T1>> PropertyDispatch.C1<T1> property(Property<T1> property1) {
        return new PropertyDispatch.C1<>(property1);
    }

    public static <T1 extends Comparable<T1>, T2 extends Comparable<T2>> PropertyDispatch.C2<T1, T2> properties(Property<T1> property1, Property<T2> property2) {
        return new PropertyDispatch.C2<>(property1, property2);
    }

    public static <T1 extends Comparable<T1>, T2 extends Comparable<T2>, T3 extends Comparable<T3>> PropertyDispatch.C3<T1, T2, T3> properties(
        Property<T1> property1, Property<T2> property2, Property<T3> property3
    ) {
        return new PropertyDispatch.C3<>(property1, property2, property3);
    }

    public static <T1 extends Comparable<T1>, T2 extends Comparable<T2>, T3 extends Comparable<T3>, T4 extends Comparable<T4>> PropertyDispatch.C4<T1, T2, T3, T4> properties(
        Property<T1> property1, Property<T2> property2, Property<T3> property3, Property<T4> property4
    ) {
        return new PropertyDispatch.C4<>(property1, property2, property3, property4);
    }

    public static <T1 extends Comparable<T1>, T2 extends Comparable<T2>, T3 extends Comparable<T3>, T4 extends Comparable<T4>, T5 extends Comparable<T5>> PropertyDispatch.C5<T1, T2, T3, T4, T5> properties(
        Property<T1> property1, Property<T2> property2, Property<T3> property3, Property<T4> property4, Property<T5> property5
    ) {
        return new PropertyDispatch.C5<>(property1, property2, property3, property4, property5);
    }

    @OnlyIn(Dist.CLIENT)
    public static class C1<T1 extends Comparable<T1>> extends PropertyDispatch {
        private final Property<T1> property1;

        C1(Property<T1> property1) {
            this.property1 = property1;
        }

        @Override
        public List<Property<?>> getDefinedProperties() {
            return ImmutableList.of(this.property1);
        }

        public PropertyDispatch.C1<T1> select(T1 value1, List<Variant> variants) {
            Selector selector = Selector.of(this.property1.value(value1));
            this.putValue(selector, variants);
            return this;
        }

        public PropertyDispatch.C1<T1> select(T1 value1, Variant variant) {
            return this.select(value1, Collections.singletonList(variant));
        }

        public PropertyDispatch generate(Function<T1, Variant> generator) {
            this.property1.getPossibleValues().forEach(p_388930_ -> this.select((T1)p_388930_, generator.apply((T1)p_388930_)));
            return this;
        }

        public PropertyDispatch generateList(Function<T1, List<Variant>> generator) {
            this.property1.getPossibleValues().forEach(p_388573_ -> this.select((T1)p_388573_, generator.apply((T1)p_388573_)));
            return this;
        }
    }

    @OnlyIn(Dist.CLIENT)
    public static class C2<T1 extends Comparable<T1>, T2 extends Comparable<T2>> extends PropertyDispatch {
        private final Property<T1> property1;
        private final Property<T2> property2;

        C2(Property<T1> property1, Property<T2> property2) {
            this.property1 = property1;
            this.property2 = property2;
        }

        @Override
        public List<Property<?>> getDefinedProperties() {
            return ImmutableList.of(this.property1, this.property2);
        }

        public PropertyDispatch.C2<T1, T2> select(T1 value1, T2 value2, List<Variant> variants) {
            Selector selector = Selector.of(this.property1.value(value1), this.property2.value(value2));
            this.putValue(selector, variants);
            return this;
        }

        public PropertyDispatch.C2<T1, T2> select(T1 value1, T2 value2, Variant variant) {
            return this.select(value1, value2, Collections.singletonList(variant));
        }

        public PropertyDispatch generate(BiFunction<T1, T2, Variant> generator) {
            this.property1
                .getPossibleValues()
                .forEach(
                    p_388697_ -> this.property2
                            .getPossibleValues()
                            .forEach(p_386785_ -> this.select((T1)p_388697_, (T2)p_386785_, generator.apply((T1)p_388697_, (T2)p_386785_)))
                );
            return this;
        }

        public PropertyDispatch generateList(BiFunction<T1, T2, List<Variant>> generator) {
            this.property1
                .getPossibleValues()
                .forEach(
                    p_387035_ -> this.property2
                            .getPossibleValues()
                            .forEach(p_386853_ -> this.select((T1)p_387035_, (T2)p_386853_, generator.apply((T1)p_387035_, (T2)p_386853_)))
                );
            return this;
        }
    }

    @OnlyIn(Dist.CLIENT)
    public static class C3<T1 extends Comparable<T1>, T2 extends Comparable<T2>, T3 extends Comparable<T3>> extends PropertyDispatch {
        private final Property<T1> property1;
        private final Property<T2> property2;
        private final Property<T3> property3;

        C3(Property<T1> property1, Property<T2> property2, Property<T3> property3) {
            this.property1 = property1;
            this.property2 = property2;
            this.property3 = property3;
        }

        @Override
        public List<Property<?>> getDefinedProperties() {
            return ImmutableList.of(this.property1, this.property2, this.property3);
        }

        public PropertyDispatch.C3<T1, T2, T3> select(T1 value1, T2 value2, T3 value3, List<Variant> variants) {
            Selector selector = Selector.of(this.property1.value(value1), this.property2.value(value2), this.property3.value(value3));
            this.putValue(selector, variants);
            return this;
        }

        public PropertyDispatch.C3<T1, T2, T3> select(T1 value1, T2 value2, T3 value3, Variant variant) {
            return this.select(value1, value2, value3, Collections.singletonList(variant));
        }

        public PropertyDispatch generate(PropertyDispatch.TriFunction<T1, T2, T3, Variant> generator) {
            this.property1
                .getPossibleValues()
                .forEach(
                    p_388004_ -> this.property2
                            .getPossibleValues()
                            .forEach(
                                p_387043_ -> this.property3
                                        .getPossibleValues()
                                        .forEach(
                                            p_387450_ -> this.select(
                                                    (T1)p_388004_, (T2)p_387043_, (T3)p_387450_, generator.apply((T1)p_388004_, (T2)p_387043_, (T3)p_387450_)
                                                )
                                        )
                            )
                );
            return this;
        }

        public PropertyDispatch generateList(PropertyDispatch.TriFunction<T1, T2, T3, List<Variant>> generator) {
            this.property1
                .getPossibleValues()
                .forEach(
                    p_387849_ -> this.property2
                            .getPossibleValues()
                            .forEach(
                                p_388797_ -> this.property3
                                        .getPossibleValues()
                                        .forEach(
                                            p_387421_ -> this.select(
                                                    (T1)p_387849_, (T2)p_388797_, (T3)p_387421_, generator.apply((T1)p_387849_, (T2)p_388797_, (T3)p_387421_)
                                                )
                                        )
                            )
                );
            return this;
        }
    }

    @OnlyIn(Dist.CLIENT)
    public static class C4<T1 extends Comparable<T1>, T2 extends Comparable<T2>, T3 extends Comparable<T3>, T4 extends Comparable<T4>> extends PropertyDispatch {
        private final Property<T1> property1;
        private final Property<T2> property2;
        private final Property<T3> property3;
        private final Property<T4> property4;

        C4(Property<T1> property1, Property<T2> property2, Property<T3> property3, Property<T4> property4) {
            this.property1 = property1;
            this.property2 = property2;
            this.property3 = property3;
            this.property4 = property4;
        }

        @Override
        public List<Property<?>> getDefinedProperties() {
            return ImmutableList.of(this.property1, this.property2, this.property3, this.property4);
        }

        public PropertyDispatch.C4<T1, T2, T3, T4> select(T1 value1, T2 value2, T3 value3, T4 value4, List<Variant> variants) {
            Selector selector = Selector.of(
                this.property1.value(value1), this.property2.value(value2), this.property3.value(value3), this.property4.value(value4)
            );
            this.putValue(selector, variants);
            return this;
        }

        public PropertyDispatch.C4<T1, T2, T3, T4> select(T1 value1, T2 value2, T3 value3, T4 value4, Variant variant) {
            return this.select(value1, value2, value3, value4, Collections.singletonList(variant));
        }

        public PropertyDispatch generate(PropertyDispatch.QuadFunction<T1, T2, T3, T4, Variant> generator) {
            this.property1
                .getPossibleValues()
                .forEach(
                    p_386818_ -> this.property2
                            .getPossibleValues()
                            .forEach(
                                p_388830_ -> this.property3
                                        .getPossibleValues()
                                        .forEach(
                                            p_387951_ -> this.property4
                                                    .getPossibleValues()
                                                    .forEach(
                                                        p_386803_ -> this.select(
                                                                (T1)p_386818_,
                                                                (T2)p_388830_,
                                                                (T3)p_387951_,
                                                                (T4)p_386803_,
                                                                generator.apply((T1)p_386818_, (T2)p_388830_, (T3)p_387951_, (T4)p_386803_)
                                                            )
                                                    )
                                        )
                            )
                );
            return this;
        }

        public PropertyDispatch generateList(PropertyDispatch.QuadFunction<T1, T2, T3, T4, List<Variant>> generator) {
            this.property1
                .getPossibleValues()
                .forEach(
                    p_387677_ -> this.property2
                            .getPossibleValues()
                            .forEach(
                                p_386868_ -> this.property3
                                        .getPossibleValues()
                                        .forEach(
                                            p_387590_ -> this.property4
                                                    .getPossibleValues()
                                                    .forEach(
                                                        p_387786_ -> this.select(
                                                                (T1)p_387677_,
                                                                (T2)p_386868_,
                                                                (T3)p_387590_,
                                                                (T4)p_387786_,
                                                                generator.apply((T1)p_387677_, (T2)p_386868_, (T3)p_387590_, (T4)p_387786_)
                                                            )
                                                    )
                                        )
                            )
                );
            return this;
        }
    }

    @OnlyIn(Dist.CLIENT)
    public static class C5<T1 extends Comparable<T1>, T2 extends Comparable<T2>, T3 extends Comparable<T3>, T4 extends Comparable<T4>, T5 extends Comparable<T5>>
        extends PropertyDispatch {
        private final Property<T1> property1;
        private final Property<T2> property2;
        private final Property<T3> property3;
        private final Property<T4> property4;
        private final Property<T5> property5;

        C5(Property<T1> property1, Property<T2> property2, Property<T3> property3, Property<T4> property4, Property<T5> property5) {
            this.property1 = property1;
            this.property2 = property2;
            this.property3 = property3;
            this.property4 = property4;
            this.property5 = property5;
        }

        @Override
        public List<Property<?>> getDefinedProperties() {
            return ImmutableList.of(this.property1, this.property2, this.property3, this.property4, this.property5);
        }

        public PropertyDispatch.C5<T1, T2, T3, T4, T5> select(T1 value1, T2 value2, T3 value3, T4 value4, T5 value5, List<Variant> variants) {
            Selector selector = Selector.of(
                this.property1.value(value1),
                this.property2.value(value2),
                this.property3.value(value3),
                this.property4.value(value4),
                this.property5.value(value5)
            );
            this.putValue(selector, variants);
            return this;
        }

        public PropertyDispatch.C5<T1, T2, T3, T4, T5> select(T1 value1, T2 value2, T3 value3, T4 value4, T5 value5, Variant variant) {
            return this.select(value1, value2, value3, value4, value5, Collections.singletonList(variant));
        }

        public PropertyDispatch generate(PropertyDispatch.PentaFunction<T1, T2, T3, T4, T5, Variant> generator) {
            this.property1
                .getPossibleValues()
                .forEach(
                    p_388135_ -> this.property2
                            .getPossibleValues()
                            .forEach(
                                p_388174_ -> this.property3
                                        .getPossibleValues()
                                        .forEach(
                                            p_387752_ -> this.property4
                                                    .getPossibleValues()
                                                    .forEach(
                                                        p_388362_ -> this.property5
                                                                .getPossibleValues()
                                                                .forEach(
                                                                    p_388281_ -> this.select(
                                                                            (T1)p_388135_,
                                                                            (T2)p_388174_,
                                                                            (T3)p_387752_,
                                                                            (T4)p_388362_,
                                                                            (T5)p_388281_,
                                                                            generator.apply(
                                                                                (T1)p_388135_, (T2)p_388174_, (T3)p_387752_, (T4)p_388362_, (T5)p_388281_
                                                                            )
                                                                        )
                                                                )
                                                    )
                                        )
                            )
                );
            return this;
        }

        public PropertyDispatch generateList(PropertyDispatch.PentaFunction<T1, T2, T3, T4, T5, List<Variant>> generator) {
            this.property1
                .getPossibleValues()
                .forEach(
                    p_387090_ -> this.property2
                            .getPossibleValues()
                            .forEach(
                                p_388322_ -> this.property3
                                        .getPossibleValues()
                                        .forEach(
                                            p_388641_ -> this.property4
                                                    .getPossibleValues()
                                                    .forEach(
                                                        p_388001_ -> this.property5
                                                                .getPossibleValues()
                                                                .forEach(
                                                                    p_387883_ -> this.select(
                                                                            (T1)p_387090_,
                                                                            (T2)p_388322_,
                                                                            (T3)p_388641_,
                                                                            (T4)p_388001_,
                                                                            (T5)p_387883_,
                                                                            generator.apply(
                                                                                (T1)p_387090_, (T2)p_388322_, (T3)p_388641_, (T4)p_388001_, (T5)p_387883_
                                                                            )
                                                                        )
                                                                )
                                                    )
                                        )
                            )
                );
            return this;
        }
    }

    @FunctionalInterface
    @OnlyIn(Dist.CLIENT)
    public interface PentaFunction<P1, P2, P3, P4, P5, R> {
        R apply(P1 p1, P2 p2, P3 p3, P4 p4, P5 p5);
    }

    @FunctionalInterface
    @OnlyIn(Dist.CLIENT)
    public interface QuadFunction<P1, P2, P3, P4, R> {
        R apply(P1 p1, P2 p2, P3 p3, P4 p4);
    }

    @FunctionalInterface
    @OnlyIn(Dist.CLIENT)
    public interface TriFunction<P1, P2, P3, R> {
        R apply(P1 p1, P2 p2, P3 p3);
    }
}
