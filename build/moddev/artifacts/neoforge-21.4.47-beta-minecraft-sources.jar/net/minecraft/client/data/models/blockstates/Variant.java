package net.minecraft.client.data.models.blockstates;

import com.google.common.collect.Maps;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class Variant implements Supplier<JsonElement> {
    private final Map<VariantProperty<?>, VariantProperty<?>.Value> values = Maps.newLinkedHashMap();

    public <T> Variant with(VariantProperty<T> property, T value) {
        VariantProperty<?>.Value variantproperty = this.values.put(property, property.withValue(value));
        if (variantproperty != null) {
            throw new IllegalStateException("Replacing value of " + variantproperty + " with " + value);
        } else {
            return this;
        }
    }

    public static Variant variant() {
        return new Variant();
    }

    public static Variant merge(Variant first, Variant second) {
        Variant variant = new Variant();
        variant.values.putAll(first.values);
        variant.values.putAll(second.values);
        return variant;
    }

    public JsonElement get() {
        JsonObject jsonobject = new JsonObject();
        this.values.values().forEach(p_387061_ -> p_387061_.addToVariant(jsonobject));
        return jsonobject;
    }

    public static JsonElement convertList(List<Variant> list) {
        if (list.size() == 1) {
            return list.get(0).get();
        } else {
            JsonArray jsonarray = new JsonArray();
            list.forEach(p_386684_ -> jsonarray.add(p_386684_.get()));
            return jsonarray;
        }
    }
}
