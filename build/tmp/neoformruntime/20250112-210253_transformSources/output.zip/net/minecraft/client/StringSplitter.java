package net.minecraft.client;

import com.google.common.collect.Lists;
import java.util.List;
import java.util.ListIterator;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;
import javax.annotation.Nullable;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.network.chat.Style;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.FormattedCharSink;
import net.minecraft.util.StringDecomposer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.apache.commons.lang3.mutable.MutableFloat;
import org.apache.commons.lang3.mutable.MutableInt;
import org.apache.commons.lang3.mutable.MutableObject;

@OnlyIn(Dist.CLIENT)
public class StringSplitter {
    final StringSplitter.WidthProvider widthProvider;

    public StringSplitter(StringSplitter.WidthProvider widthProvider) {
        this.widthProvider = widthProvider;
    }

    public float stringWidth(@Nullable String content) {
        if (content == null) {
            return 0.0F;
        } else {
            MutableFloat mutablefloat = new MutableFloat();
            StringDecomposer.iterateFormatted(content, Style.EMPTY, (p_92429_, p_92430_, p_92431_) -> {
                mutablefloat.add(this.widthProvider.getWidth(p_92431_, p_92430_));
                return true;
            });
            return mutablefloat.floatValue();
        }
    }

    public float stringWidth(FormattedText content) {
        MutableFloat mutablefloat = new MutableFloat();
        StringDecomposer.iterateFormatted(content, Style.EMPTY, (p_92420_, p_92421_, p_92422_) -> {
            mutablefloat.add(this.widthProvider.getWidth(p_92422_, p_92421_));
            return true;
        });
        return mutablefloat.floatValue();
    }

    public float stringWidth(FormattedCharSequence content) {
        MutableFloat mutablefloat = new MutableFloat();
        content.accept((p_92400_, p_92401_, p_92402_) -> {
            mutablefloat.add(this.widthProvider.getWidth(p_92402_, p_92401_));
            return true;
        });
        return mutablefloat.floatValue();
    }

    public int plainIndexAtWidth(String content, int maxWidth, Style style) {
        StringSplitter.WidthLimitedCharSink stringsplitter$widthlimitedcharsink = new StringSplitter.WidthLimitedCharSink((float)maxWidth);
        StringDecomposer.iterate(content, style, stringsplitter$widthlimitedcharsink);
        return stringsplitter$widthlimitedcharsink.getPosition();
    }

    public String plainHeadByWidth(String content, int maxWidth, Style style) {
        return content.substring(0, this.plainIndexAtWidth(content, maxWidth, style));
    }

    public String plainTailByWidth(String content, int maxWidth, Style style) {
        MutableFloat mutablefloat = new MutableFloat();
        MutableInt mutableint = new MutableInt(content.length());
        StringDecomposer.iterateBackwards(content, style, (p_92407_, p_92408_, p_92409_) -> {
            float f = mutablefloat.addAndGet(this.widthProvider.getWidth(p_92409_, p_92408_));
            if (f > (float)maxWidth) {
                return false;
            } else {
                mutableint.setValue(p_92407_);
                return true;
            }
        });
        return content.substring(mutableint.intValue());
    }

    public int formattedIndexByWidth(String content, int maxWidth, Style style) {
        StringSplitter.WidthLimitedCharSink stringsplitter$widthlimitedcharsink = new StringSplitter.WidthLimitedCharSink((float)maxWidth);
        StringDecomposer.iterateFormatted(content, style, stringsplitter$widthlimitedcharsink);
        return stringsplitter$widthlimitedcharsink.getPosition();
    }

    @Nullable
    public Style componentStyleAtWidth(FormattedText content, int maxWidth) {
        StringSplitter.WidthLimitedCharSink stringsplitter$widthlimitedcharsink = new StringSplitter.WidthLimitedCharSink((float)maxWidth);
        return content.<Style>visit(
                (p_92343_, p_92344_) -> StringDecomposer.iterateFormatted(p_92344_, p_92343_, stringsplitter$widthlimitedcharsink)
                        ? Optional.empty()
                        : Optional.of(p_92343_),
                Style.EMPTY
            )
            .orElse(null);
    }

    @Nullable
    public Style componentStyleAtWidth(FormattedCharSequence content, int maxWidth) {
        StringSplitter.WidthLimitedCharSink stringsplitter$widthlimitedcharsink = new StringSplitter.WidthLimitedCharSink((float)maxWidth);
        MutableObject<Style> mutableobject = new MutableObject<>();
        content.accept((p_92348_, p_92349_, p_92350_) -> {
            if (!stringsplitter$widthlimitedcharsink.accept(p_92348_, p_92349_, p_92350_)) {
                mutableobject.setValue(p_92349_);
                return false;
            } else {
                return true;
            }
        });
        return mutableobject.getValue();
    }

    public String formattedHeadByWidth(String content, int maxWidth, Style style) {
        return content.substring(0, this.formattedIndexByWidth(content, maxWidth, style));
    }

    public FormattedText headByWidth(FormattedText content, int maxWidth, Style style) {
        final StringSplitter.WidthLimitedCharSink stringsplitter$widthlimitedcharsink = new StringSplitter.WidthLimitedCharSink((float)maxWidth);
        return content.visit(new FormattedText.StyledContentConsumer<FormattedText>() {
            private final ComponentCollector collector = new ComponentCollector();

            @Override
            public Optional<FormattedText> accept(Style p_92443_, String p_92444_) {
                stringsplitter$widthlimitedcharsink.resetPosition();
                if (!StringDecomposer.iterateFormatted(p_92444_, p_92443_, stringsplitter$widthlimitedcharsink)) {
                    String s = p_92444_.substring(0, stringsplitter$widthlimitedcharsink.getPosition());
                    if (!s.isEmpty()) {
                        this.collector.append(FormattedText.of(s, p_92443_));
                    }

                    return Optional.of(this.collector.getResultOrEmpty());
                } else {
                    if (!p_92444_.isEmpty()) {
                        this.collector.append(FormattedText.of(p_92444_, p_92443_));
                    }

                    return Optional.empty();
                }
            }
        }, style).orElse(content);
    }

    public int findLineBreak(String content, int maxWidth, Style style) {
        StringSplitter.LineBreakFinder stringsplitter$linebreakfinder = new StringSplitter.LineBreakFinder((float)maxWidth);
        StringDecomposer.iterateFormatted(content, style, stringsplitter$linebreakfinder);
        return stringsplitter$linebreakfinder.getSplitPosition();
    }

    public static int getWordPosition(String content, int skipCount, int cursorPoint, boolean includeWhitespace) {
        int i = cursorPoint;
        boolean flag = skipCount < 0;
        int j = Math.abs(skipCount);

        for (int k = 0; k < j; k++) {
            if (flag) {
                while (includeWhitespace && i > 0 && (content.charAt(i - 1) == ' ' || content.charAt(i - 1) == '\n')) {
                    i--;
                }

                while (i > 0 && content.charAt(i - 1) != ' ' && content.charAt(i - 1) != '\n') {
                    i--;
                }
            } else {
                int l = content.length();
                int i1 = content.indexOf(32, i);
                int j1 = content.indexOf(10, i);
                if (i1 == -1 && j1 == -1) {
                    i = -1;
                } else if (i1 != -1 && j1 != -1) {
                    i = Math.min(i1, j1);
                } else if (i1 != -1) {
                    i = i1;
                } else {
                    i = j1;
                }

                if (i == -1) {
                    i = l;
                } else {
                    while (includeWhitespace && i < l && (content.charAt(i) == ' ' || content.charAt(i) == '\n')) {
                        i++;
                    }
                }
            }
        }

        return i;
    }

    public void splitLines(String content, int maxWidth, Style p_style, boolean withNewLines, StringSplitter.LinePosConsumer linePos) {
        int i = 0;
        int j = content.length();
        Style style = p_style;

        while (i < j) {
            StringSplitter.LineBreakFinder stringsplitter$linebreakfinder = new StringSplitter.LineBreakFinder((float)maxWidth);
            boolean flag = StringDecomposer.iterateFormatted(content, i, style, p_style, stringsplitter$linebreakfinder);
            if (flag) {
                linePos.accept(style, i, j);
                break;
            }

            int k = stringsplitter$linebreakfinder.getSplitPosition();
            char c0 = content.charAt(k);
            int l = c0 != '\n' && c0 != ' ' ? k : k + 1;
            linePos.accept(style, i, withNewLines ? l : k);
            i = l;
            style = stringsplitter$linebreakfinder.getSplitStyle();
        }
    }

    public List<FormattedText> splitLines(String content, int maxWidth, Style style) {
        List<FormattedText> list = Lists.newArrayList();
        this.splitLines(
            content, maxWidth, style, false, (p_92373_, p_92374_, p_92375_) -> list.add(FormattedText.of(content.substring(p_92374_, p_92375_), p_92373_))
        );
        return list;
    }

    public List<FormattedText> splitLines(FormattedText content, int maxWidth, Style style) {
        List<FormattedText> list = Lists.newArrayList();
        this.splitLines(content, maxWidth, style, (p_92378_, p_92379_) -> list.add(p_92378_));
        return list;
    }

    public List<FormattedText> splitLines(FormattedText content, int maxWidth, Style style, FormattedText prefix) {
        List<FormattedText> list = Lists.newArrayList();
        this.splitLines(
            content, maxWidth, style, (p_168619_, p_168620_) -> list.add(p_168620_ ? FormattedText.composite(prefix, p_168619_) : p_168619_)
        );
        return list;
    }

    public void splitLines(FormattedText content, int maxWidth, Style p_style, BiConsumer<FormattedText, Boolean> splitifier) {
        List<StringSplitter.LineComponent> list = Lists.newArrayList();
        content.visit((p_92382_, p_92383_) -> {
            if (!p_92383_.isEmpty()) {
                list.add(new StringSplitter.LineComponent(p_92383_, p_92382_));
            }

            return Optional.empty();
        }, p_style);
        StringSplitter.FlatComponents stringsplitter$flatcomponents = new StringSplitter.FlatComponents(list);
        boolean flag = true;
        boolean flag1 = false;
        boolean flag2 = false;

        while (flag) {
            flag = false;
            StringSplitter.LineBreakFinder stringsplitter$linebreakfinder = new StringSplitter.LineBreakFinder((float)maxWidth);

            for (StringSplitter.LineComponent stringsplitter$linecomponent : stringsplitter$flatcomponents.parts) {
                boolean flag3 = StringDecomposer.iterateFormatted(
                    stringsplitter$linecomponent.contents, 0, stringsplitter$linecomponent.style, p_style, stringsplitter$linebreakfinder
                );
                if (!flag3) {
                    int i = stringsplitter$linebreakfinder.getSplitPosition();
                    Style style = stringsplitter$linebreakfinder.getSplitStyle();
                    char c0 = stringsplitter$flatcomponents.charAt(i);
                    boolean flag4 = c0 == '\n';
                    boolean flag5 = flag4 || c0 == ' ';
                    flag1 = flag4;
                    FormattedText formattedtext = stringsplitter$flatcomponents.splitAt(i, flag5 ? 1 : 0, style);
                    splitifier.accept(formattedtext, flag2);
                    flag2 = !flag4;
                    flag = true;
                    break;
                }

                stringsplitter$linebreakfinder.addToOffset(stringsplitter$linecomponent.contents.length());
            }
        }

        FormattedText formattedtext1 = stringsplitter$flatcomponents.getRemainder();
        if (formattedtext1 != null) {
            splitifier.accept(formattedtext1, flag2);
        } else if (flag1) {
            splitifier.accept(FormattedText.EMPTY, false);
        }
    }

    @OnlyIn(Dist.CLIENT)
    static class FlatComponents {
        final List<StringSplitter.LineComponent> parts;
        private String flatParts;

        public FlatComponents(List<StringSplitter.LineComponent> parts) {
            this.parts = parts;
            this.flatParts = parts.stream().map(p_92459_ -> p_92459_.contents).collect(Collectors.joining());
        }

        public char charAt(int codePoint) {
            return this.flatParts.charAt(codePoint);
        }

        public FormattedText splitAt(int begin, int end, Style style) {
            ComponentCollector componentcollector = new ComponentCollector();
            ListIterator<StringSplitter.LineComponent> listiterator = this.parts.listIterator();
            int i = begin;
            boolean flag = false;

            while (listiterator.hasNext()) {
                StringSplitter.LineComponent stringsplitter$linecomponent = listiterator.next();
                String s = stringsplitter$linecomponent.contents;
                int j = s.length();
                if (!flag) {
                    if (i > j) {
                        componentcollector.append(stringsplitter$linecomponent);
                        listiterator.remove();
                        i -= j;
                    } else {
                        String s1 = s.substring(0, i);
                        if (!s1.isEmpty()) {
                            componentcollector.append(FormattedText.of(s1, stringsplitter$linecomponent.style));
                        }

                        i += end;
                        flag = true;
                    }
                }

                if (flag) {
                    if (i <= j) {
                        String s2 = s.substring(i);
                        if (s2.isEmpty()) {
                            listiterator.remove();
                        } else {
                            listiterator.set(new StringSplitter.LineComponent(s2, style));
                        }
                        break;
                    }

                    listiterator.remove();
                    i -= j;
                }
            }

            this.flatParts = this.flatParts.substring(begin + end);
            return componentcollector.getResultOrEmpty();
        }

        @Nullable
        public FormattedText getRemainder() {
            ComponentCollector componentcollector = new ComponentCollector();
            this.parts.forEach(componentcollector::append);
            this.parts.clear();
            return componentcollector.getResult();
        }
    }

    @OnlyIn(Dist.CLIENT)
    class LineBreakFinder implements FormattedCharSink {
        private final float maxWidth;
        private int lineBreak = -1;
        private Style lineBreakStyle = Style.EMPTY;
        private boolean hadNonZeroWidthChar;
        private float width;
        private int lastSpace = -1;
        private Style lastSpaceStyle = Style.EMPTY;
        private int nextChar;
        private int offset;

        public LineBreakFinder(float maxWidth) {
            this.maxWidth = Math.max(maxWidth, 1.0F);
        }

        /**
         * Accepts a single code point from a {@link net.minecraft.util.FormattedCharSequence}.
         * @return {@code true} to accept more characters, {@code false} to stop traversing the sequence.
         *
         * @param positionInCurrentSequence Contains the relative position of the
         *                                  character in the current sub-sequence. If
         *                                  multiple formatted char sequences have been
         *                                  combined, this value will reset to {@code 0}
         *                                  after each sequence has been fully consumed.
         */
        @Override
        public boolean accept(int positionInCurrentSequence, Style style, int codePoint) {
            int i = positionInCurrentSequence + this.offset;
            switch (codePoint) {
                case 10:
                    return this.finishIteration(i, style);
                case 32:
                    this.lastSpace = i;
                    this.lastSpaceStyle = style;
                default:
                    float f = StringSplitter.this.widthProvider.getWidth(codePoint, style);
                    this.width += f;
                    if (!this.hadNonZeroWidthChar || !(this.width > this.maxWidth)) {
                        this.hadNonZeroWidthChar |= f != 0.0F;
                        this.nextChar = i + Character.charCount(codePoint);
                        return true;
                    } else {
                        return this.lastSpace != -1 ? this.finishIteration(this.lastSpace, this.lastSpaceStyle) : this.finishIteration(i, style);
                    }
            }
        }

        private boolean finishIteration(int lineBreak, Style lineBreakStyle) {
            this.lineBreak = lineBreak;
            this.lineBreakStyle = lineBreakStyle;
            return false;
        }

        private boolean lineBreakFound() {
            return this.lineBreak != -1;
        }

        public int getSplitPosition() {
            return this.lineBreakFound() ? this.lineBreak : this.nextChar;
        }

        public Style getSplitStyle() {
            return this.lineBreakStyle;
        }

        public void addToOffset(int offset) {
            this.offset += offset;
        }
    }

    @OnlyIn(Dist.CLIENT)
    static class LineComponent implements FormattedText {
        final String contents;
        final Style style;

        public LineComponent(String contents, Style style) {
            this.contents = contents;
            this.style = style;
        }

        @Override
        public <T> Optional<T> visit(FormattedText.ContentConsumer<T> acceptor) {
            return acceptor.accept(this.contents);
        }

        @Override
        public <T> Optional<T> visit(FormattedText.StyledContentConsumer<T> acceptor, Style style) {
            return acceptor.accept(this.style.applyTo(style), this.contents);
        }
    }

    @FunctionalInterface
    @OnlyIn(Dist.CLIENT)
    public interface LinePosConsumer {
        void accept(Style style, int currentPos, int contentWidth);
    }

    @OnlyIn(Dist.CLIENT)
    class WidthLimitedCharSink implements FormattedCharSink {
        private float maxWidth;
        private int position;

        public WidthLimitedCharSink(float maxWidth) {
            this.maxWidth = maxWidth;
        }

        /**
         * Accepts a single code point from a {@link net.minecraft.util.FormattedCharSequence}.
         * @return {@code true} to accept more characters, {@code false} to stop traversing the sequence.
         *
         * @param positionInCurrentSequence Contains the relative position of the
         *                                  character in the current sub-sequence. If
         *                                  multiple formatted char sequences have been
         *                                  combined, this value will reset to {@code 0}
         *                                  after each sequence has been fully consumed.
         */
        @Override
        public boolean accept(int positionInCurrentSequence, Style style, int codePoint) {
            this.maxWidth = this.maxWidth - StringSplitter.this.widthProvider.getWidth(codePoint, style);
            if (this.maxWidth >= 0.0F) {
                this.position = positionInCurrentSequence + Character.charCount(codePoint);
                return true;
            } else {
                return false;
            }
        }

        public int getPosition() {
            return this.position;
        }

        public void resetPosition() {
            this.position = 0;
        }
    }

    @FunctionalInterface
    @OnlyIn(Dist.CLIENT)
    public interface WidthProvider {
        float getWidth(int codePoint, Style style);
    }
}
